package in.sunbase.service;

import java.util.List;

import org.springframework.data.domain.Pageable;
import in.sunbase.entity.CustomerEntity;
import in.sunbase.entity.SearchCustomer;

public interface CustomerService {
	
	public List<CustomerEntity> getSearchCust(SearchCustomer searcust);
	public List<CustomerEntity> getAllCustomer1();
	public CustomerEntity saveCustomerEntity(CustomerEntity cust);
	public void updateCustomerEntity(Integer cid,CustomerEntity cust);
	public List<CustomerEntity> getAllCustomerEntity(Pageable pageable);
	public CustomerEntity getCustomerById(Integer cid);
	public void deleteCustomerEntity(Integer cid);

}
