package in.sunbase.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Pageable;
//import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import in.sunbase.entity.CustomerEntity;
import in.sunbase.entity.SearchCustomer;
import in.sunbase.repository.CustomerRepository;
import reactor.core.publisher.Mono;

@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	private CustomerRepository repo;
		
//	private String Get_All_Customer="http://localhost:9191/api/allcustomer";				//1.get
	private String Get_all_Record="http://localhost:9191/api/allrecordcustomer";			//1.get
//	private String Delete_Customer_ByID="http://localhost:9191/api/deletecustomer/{cid}";	//2.delete
//	private String Get_Customer_By_Cid="http://localhost:9191/api/findcustomer/{cid}";		//3.get
	private String Save_Customer="http://localhost:9191/api/savecustomer";					//4.post
//	private String Search_Customer_By_searchCust="http://localhost:9191/api/searchcustomer";//5.post
	private String Put_Customer="http://localhost:9191/api/updatecustomer/{cid}";			//6.put
	
//1.AllCustomer
	public List<CustomerEntity> getAllCustomer1()
	{
/**
		List<CustomerEntity> list2=new ArrayList<CustomerEntity>();
		RestTemplate rt=new RestTemplate();
		ResponseEntity<CustomerEntity> respEntity=rt.getForEntity(Get_All_Customer,CustomerEntity.class);
		CustomerEntity custmer=respEntity.getBody();
		list2.add(custmer);		
//		repo.findAll(Example.of(c1));
	
		WebClient webClient=WebClient.create();
		List<CustomerEntity> customer=(List<CustomerEntity>) webClient.get()
										.uri("Get_all_Record")
										.retrieve()
										.bodyToFlux(CustomerEntity.class)
										.collectList()
										.block();
		*/
		WebClient webClient=WebClient.create();
		Mono<List<CustomerEntity>> response = webClient.get()
											  .uri(Get_all_Record)
											  .retrieve()
				  .bodyToMono(new ParameterizedTypeReference<List<CustomerEntity>>() {});
		List<CustomerEntity> customer = response.block();
		for (CustomerEntity customerEntity : customer) {
			repo.save(customerEntity);
	}
		return repo.findAll();
	}
	
//2.Delete by id	
	@Override
	public void deleteCustomerEntity(Integer cid) {
/**
		RestTemplate rt=new RestTemplate();
		rt.delete(Delete_Customer_ByID,  cid);
		repo.deleteById(cid);
		
		WebClient webClient=WebClient.create();
							webClient.delete()
							.uri("Delete_Customer_ByID", cid)
							.retrieve()
							.toBodilessEntity()
							.subscribe();
*/
		repo.deleteById(cid);
	}
	
//3.Get Customer by id
	@Override
	public CustomerEntity getCustomerById(Integer cid) {
/**
		RestTemplate rt=new RestTemplate();
		ResponseEntity<CustomerEntity> respEntity=rt.getForEntity(Get_Customer_By_Cid, CustomerEntity.class, cid);
		CustomerEntity customer=respEntity.getBody();
//		repo.getById(cid);
		
		WebClient webclint=WebClient.create();
		CustomerEntity customer=webclint.get()
								.uri(Get_Customer_By_Cid,cid)
								.retrieve()
								.bodyToMono(CustomerEntity.class)
								.block();
	repo.getById(cid);	
 */
		return repo.getById(cid);
	}
	
//4.Save Customer	
	@Override
	public CustomerEntity saveCustomerEntity(CustomerEntity cust) {
/**
		RestTemplate rt=new RestTemplate();
		ResponseEntity<CustomerEntity> respEntity=rt.postForEntity(Save_Customer, cust, CustomerEntity.class);
		CustomerEntity custmer=respEntity.getBody();
*/		
		WebClient webClient=WebClient.create();
		CustomerEntity c1=(CustomerEntity) webClient.post()
								.uri(Save_Customer)
								.bodyValue(cust)
								.retrieve()
								.bodyToMono(CustomerEntity.class)
								.subscribe();
			
			return repo.save(cust);
	}

//5.search customer by search customer
	public List<CustomerEntity> getSearchCust(SearchCustomer searcust) {
		CustomerEntity c1=new CustomerEntity();
		if(!searcust.getFirst_Name().isEmpty() && !"".equals(searcust.getFirst_Name()))
		c1.setFirst_Name(searcust.getFirst_Name());
		
		if(!searcust.getCity().isEmpty() && !"".equals(searcust.getCity()))
		c1.setCity(searcust.getCity());
		
		if(!searcust.getEmail().isEmpty() && !"".equals(searcust.getEmail()))
		c1.setEmail(searcust.getEmail());
		
		if(!searcust.getPhoneNo().isEmpty() && !"".equals(searcust.getPhoneNo()))
		c1.setPhoneNo(searcust.getPhoneNo());
/**
		List<CustomerEntity> list3=new ArrayList<CustomerEntity>();
		RestTemplate rt=new RestTemplate();
		ResponseEntity<CustomerEntity> respEntity=rt.postForEntity(Search_Customer_By_searchCust, searcust, CustomerEntity.class);
		CustomerEntity custmer=respEntity.getBody();
		list3.add(custmer);
		
//	   repo.findAll(Example.of(c1));
		
		WebClient webclint=WebClient.create();
		@SuppressWarnings("unchecked")
		List<CustomerEntity> customer=(List<CustomerEntity>) webclint.post()
									.uri(Search_Customer_By_searchCust,c1)
									.retrieve()
									.bodyToFlux(CustomerEntity.class)
									.collectList()
									.block();
*/
		return 	repo.findAll(Example.of(c1));
	}
	
//6.Update Customer
	@Override
	public void updateCustomerEntity(Integer cid, CustomerEntity cust) {
	/**	
		RestTemplate rt=new RestTemplate();
		rt.put(Put_Customer,cid,cust);	
		if(repo.existsById(cid))
			repo.save(cust);
		*/
		WebClient webclint=WebClient.create();
						   webclint.put()
						   .uri(Put_Customer,cid)
						   .bodyValue(cust)
						   .retrieve()
						   .bodyToMono(CustomerEntity.class)
						   .subscribe();
		if(repo.existsById(cid))
			repo.save(cust);
	}

	@Override
	public List<CustomerEntity> getAllCustomerEntity(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}
}
