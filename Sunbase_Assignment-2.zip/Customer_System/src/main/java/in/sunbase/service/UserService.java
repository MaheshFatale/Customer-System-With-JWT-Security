package in.sunbase.service;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import in.sunbase.binding.UserEntity;
@Service
public class UserService {
	
	private String User_Register="http://localhost:9191/api/register";
	private String User_Authenticate="http://localhost:9191/api/authenticate";
	public void registerUser(UserEntity user)
	{
		WebClient webclint=WebClient.create();
				webclint.post()
				.uri(User_Register)
				.bodyValue(user)
				.retrieve()
				.bodyToMono(String.class)
				.subscribe();

		
		
	}
	
	public void AuthenticateUser(UserEntity user)
	{
		WebClient webclint=WebClient.create();
							webclint.post()
						   .uri(User_Authenticate)
						   .bodyValue(user)
						   .retrieve()
						   .bodyToMono(String.class)
						   .subscribe();
	
	
	}

}
