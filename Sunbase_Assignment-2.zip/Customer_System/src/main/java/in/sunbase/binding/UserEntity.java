package in.sunbase.binding;
import lombok.Data;
@Data
public class UserEntity {

    private String username;
    private String password;
}

