package in.SunbaseApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SunbaseAssignment1Application {

	public static void main(String[] args) {
		SpringApplication.run(SunbaseAssignment1Application.class, args);
	}

}
